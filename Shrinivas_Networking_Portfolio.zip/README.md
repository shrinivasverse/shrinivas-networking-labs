# S Shrinivas — Networking Portfolio

A single-page portfolio built for an entry-level NOC / Network Support / IT Infrastructure job search.

## Included
- Dark, recruiter-friendly responsive design inspired by modern engineering portfolios
- About / skills / projects / troubleshooting / learning / contact sections
- Cisco Packet Tracer projects: VLANs, router-on-a-stick, static routing, OSPF, DHCP, DNS, trunk troubleshooting
- Command reference chips for commonly practiced troubleshooting commands
- CCNA shown honestly as "Currently preparing"
- Mobile navigation and scroll-reveal animations

## Before publishing
Replace these placeholders in `index.html`:
- `your.email@example.com`
- Resume link (`#` near "Open resume")
- LinkedIn URL if your live profile URL differs

Optional: add a phone number only if you want it public.

## Publish free
### GitHub Pages
1. Create a GitHub repository, e.g. `shrinivas-networking-portfolio`.
2. Upload `index.html`, `style.css`, `script.js` and this README.
3. In GitHub: Settings → Pages → Deploy from branch → `main` / root.
4. Add a custom domain later if you purchase one.

### Netlify / Vercel
Upload the folder as a static site or connect the GitHub repository.
